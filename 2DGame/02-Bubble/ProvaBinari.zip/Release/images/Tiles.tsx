<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tiles" tilewidth="8" tileheight="8" tilecount="30" columns="5">
 <image source="Tiles.png" width="40" height="48"/>
</tileset>
